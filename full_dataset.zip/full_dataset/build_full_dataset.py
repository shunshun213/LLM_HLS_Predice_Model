#!/usr/bin/env python3
"""
Merge train_mixed_rtl_hls_dataset (216 samples) and extra_dataset (successful sweep runs) into
one dataset: full_dataset/.

  full_dataset/samples/<name>/   copy of each sample folder (run.tcl, result.json, report/, hls.log, verilog/)
  full_dataset/index.csv         one row per sample, union of both index schemas + source / group
  full_dataset/dataset.jsonl     one result.json per line, with sample / source / group added
  full_dataset/gemm_base.cpp     the synthesized source (identical in both datasets)

Only extra runs with status 'ok' are taken (configs already in the training set were skipped
when the sweeps ran, so there are no duplicates). The original folders are not modified.

Usage: python3 build_full_dataset.py <project_root>
"""
import csv
import filecmp
import glob
import json
import os
import shutil
import sys

root = sys.argv[1] if len(sys.argv) > 1 else "."
TRAIN = os.path.join(root, "train_mixed_rtl_hls_dataset")
EXTRA = os.path.join(root, "extra_dataset")
OUT = os.path.join(root, "full_dataset")
os.makedirs(os.path.join(OUT, "samples"), exist_ok=True)

assert filecmp.cmp(os.path.join(TRAIN, "gemm_base.cpp"), os.path.join(EXTRA, "gemm_base.cpp"), shallow=False), \
    "gemm_base.cpp differs between the two datasets"
shutil.copy2(os.path.join(TRAIN, "gemm_base.cpp"), os.path.join(OUT, "gemm_base.cpp"))


def read_index(path):
    with open(path, newline="") as f:
        return {r["sample"]: r for r in csv.DictReader(f)}


def sync_tree(src, dst):
    """Copy files that are missing or differ in size (resumable; never deletes)."""
    n = 0
    for dp, _, files in os.walk(src):
        rel = os.path.relpath(dp, src)
        od = os.path.join(dst, rel)
        os.makedirs(od, exist_ok=True)
        for fn in files:
            s, d = os.path.join(dp, fn), os.path.join(od, fn)
            if fn == "result.json" and rel == ".":
                continue  # written below with source/group tags
            if not os.path.exists(d) or os.path.getsize(d) != os.path.getsize(s):
                shutil.copy2(s, d)
                n += 1
    return n


idx = {"train": read_index(os.path.join(TRAIN, "index.csv")),
       "extra": read_index(os.path.join(EXTRA, "index.csv"))}

rows, jsonl, keys = [], [], set()
for source, base in (("train", TRAIN), ("extra", EXTRA)):
    for sd in sorted(glob.glob(os.path.join(base, "samples", "*"))):
        name = os.path.basename(sd)
        res = json.load(open(os.path.join(sd, "result.json")))
        if res.get("status") != "ok" or not os.path.exists(os.path.join(sd, "report", "gemm_csynth.rpt")):
            continue
        if res["key"] in keys:
            raise SystemExit(f"duplicate config key {res['key']} ({name})")
        keys.add(res["key"])
        group = res.get("sweep") or name.rsplit("_", 2)[0]
        dst = os.path.join(OUT, "samples", name)
        sync_tree(sd, dst)
        # tag the copied result.json with its origin
        res_out = dict(res, source=source, group=group)
        with open(os.path.join(dst, "result.json"), "w") as f:
            json.dump(res_out, f, indent=2)
        row = dict(idx[source].get(name, {}))
        row.update({"sample": name, "source": source, "group": group})
        rows.append(row)
        jsonl.append(dict(res_out, sample=name))

cols = ["sample", "source", "group"]
for r in rows:
    for k in r:
        if k not in cols:
            cols.append(k)
with open(os.path.join(OUT, "index.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=cols)
    w.writeheader()
    w.writerows(rows)
with open(os.path.join(OUT, "dataset.jsonl"), "w") as f:
    for r in jsonl:
        f.write(json.dumps(r) + "\n")

from collections import Counter
print(json.dumps({"samples": len(rows), "by_source": Counter(r["source"] for r in rows),
                  "groups": len({r["group"] for r in rows})}))
