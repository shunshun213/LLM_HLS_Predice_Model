open_project -reset proj
set_top gemm
add_files {gemm_base.cpp} -cflags "-DN=64"
open_solution -reset sol -flow_target vivado
set_part {xczu3eg-sbva484-1-i}
create_clock -period 10.0
config_compile -pipeline_loops 0 -unsafe_math_optimizations
config_array_partition -throughput_driven off
set_directive_pipeline -II 1 -style flp "gemm/loop_j"
set_directive_array_reshape -type complete -dim 1 "gemm" lA
set_directive_array_partition -type cyclic -factor 4 -dim 2 "gemm" lB
set_directive_array_reshape -type cyclic -factor 8 -dim 1 "gemm" lC
set_directive_bind_storage -type ram_1p -impl lutram "gemm" lA
set_directive_bind_op -op fmul -impl fabric -latency 4 "gemm/loop_k" prod
set_directive_bind_op -op fadd -impl fulldsp -latency 3 "gemm/loop_k" acc
csynth_design
exit
