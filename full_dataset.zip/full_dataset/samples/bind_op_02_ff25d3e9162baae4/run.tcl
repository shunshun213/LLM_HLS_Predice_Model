open_project -reset proj
set_top gemm
add_files {gemm_base.cpp} -cflags "-DN=64"
open_solution -reset sol -flow_target vivado
set_part {xczu3eg-sbva484-1-i}
create_clock -period 10.0
config_compile -pipeline_loops 0
config_array_partition -throughput_driven off
set_directive_bind_op -op fmul -impl fulldsp -latency 4 "gemm/loop_k" prod
csynth_design
exit
