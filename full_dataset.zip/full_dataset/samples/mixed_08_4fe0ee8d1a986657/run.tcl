open_project -reset proj
set_top gemm
add_files {gemm_base.cpp} -cflags "-DN=64"
open_solution -reset sol -flow_target vivado
set_part {xczu3eg-sbva484-1-i}
create_clock -period 3.33
config_compile -pipeline_loops 0
config_array_partition -throughput_driven off
set_directive_unroll -factor 32 "gemm/loop_k"
set_directive_unroll -factor 4 "gemm/loop_j"
set_directive_array_partition -type cyclic -factor 16 -dim 2 "gemm" lB
set_directive_array_reshape -type complete -dim 2 "gemm" lC
set_directive_bind_storage -type ram_t2p "gemm" lA
set_directive_bind_op -op fmul -impl maxdsp -latency 1 "gemm/loop_k" prod
set_directive_bind_op -op fadd -impl fabric -latency 3 "gemm/loop_k" acc
set_directive_loop_flatten -off "gemm/loop_j"
set_directive_loop_flatten -off "gemm/loop_k"
csynth_design
exit
