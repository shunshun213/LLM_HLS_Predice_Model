# full_dataset: GEMM Vitis HLS dataset (train + extra sweeps)

One dataset of 510 synthesized GEMM designs: the 216 samples of `train_mixed_rtl_hls_dataset`
plus the 294 successful one-factor sweep runs of `extra_dataset` (S1–S6 in `dataset_request.md`).
Same kernel, tool and flow throughout: `gemm_base.cpp`, `-DN=64`, Vitis HLS 2023.2,
`xczu3eg-sbva484-1-i`, `config_compile -pipeline_loops 0`, `config_array_partition -throughput_driven off`.

The original folders are unchanged. Rebuild with:

    python3 full_dataset/build_full_dataset.py .
    python3 hs_dataset/hs_extract.py full_dataset full_dataset/hs

## Contents

| Path | Contents |
|---|---|
| `samples/<name>/` | 510 sample folders: `run.tcl`, `result.json`, `report/`, `hls.log`, `verilog/` (and `gemm_pragmas.cpp` for train samples) |
| `index.csv` | one row per sample: `sample`, `source`, `group`, then the union of both original index schemas (train-only and extra-only columns are empty for the other source) |
| `dataset.jsonl` | one `result.json` per line, with `sample`, `source`, `group` added |
| `gemm_base.cpp` | the synthesized source (identical in both datasets, checked) |
| `hs/` | Stage 1 / Stage 2 files for all 510 samples, same format as `hs_dataset/` (see `hs_dataset/README.md`) |
| `build_full_dataset.py` | the merge script |

Fields added to every `result.json` and row:
- `source`: `train` (original 216) or `extra` (sweep runs)
- `group`: the training suite (e.g. `mixed`, `bind_op`) or the sweep (e.g. `S1a_fmul`, `S4b_lB`); 31 groups

## What was merged

- All 216 train samples and the 294 extra samples with status `ok`. No config key appears twice:
  sweep configs that already existed in the training set were skipped when the sweeps ran.
- Left out: the 3 extra runs HLS rejected (`ram_t2p` + `lutram`, S5a #16, #17, S5b #8). Their
  evidence stays in `extra_dataset/samples/`.
- Copy verified: 13,698 files, all present with identical sizes.
- All extraction checks pass on 510/510 (instance sums, memory BRAM, bottom-up resource totals,
  targets vs `result.json`, fits flag, latency reconciliation, log vs report depth, II limiter).

## Overview

| | |
|---|---|
| Samples | 510 (train 216, extra 294) |
| Clock targets (ns) | 10.0: 281, 5.0: 72, 3.33: 69, 2.5: 88 |
| Compute loop pipelined | 455; target II met in 68 |
| II limiter when missed | recurrence 263, memory port 124 |
| Not fitting the device | 39 |

## How to use it for evaluation

The extra samples are one-factor-at-a-time sweeps around three base designs, so their spread is
not the spread of the training suites (and presumably of the hidden test set). Use `source` to
keep that apart:
- derive rules and constants from all 510;
- report Judgement A / B on `source == train` (the 216 originals), and break results down by `group`;
- for a generalization check, hold out whole groups (leave-one-group-out), not random samples.
